/* Auto-generated - leave alone and don't commit! */

#define JAILHOUSE_VERSION	"v0.9.1"
