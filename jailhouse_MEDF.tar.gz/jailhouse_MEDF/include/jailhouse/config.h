#define CONFIG_TRACE_ERROR             1
#define CONFIG_ARM_GIC_V2              1
#define CONFIG_MACH_NXP_S32            1
#define CONFIG_NO_SMC                  1
