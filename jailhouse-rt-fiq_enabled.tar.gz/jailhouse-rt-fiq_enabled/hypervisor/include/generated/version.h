/* Auto-generated - leave alone and don't commit! */

#define JAILHOUSE_VERSION	"v0.12 (89-ge2e8d42-dirty)"
