#!/bin/bash
../sd-vbs-bin/disparity/data/vga/disparity ../sd-vbs-bin/disparity/data/vga/
